package com.dervan.module.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dervan.module.dao.DataBaseConnection;

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static final String DBNAME = "Sport_Database";
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "Dynamic123";

	private static final String LOGIN_QUERY = "select * from members where uname=? and pass=?";
	private static final String ADMIN_PAGE = "jsp/admin.jsp";
	private static final String SUSER_PAGE = "jsp/suser.jsp";
	private static final String RUSER_PAGE = "jsp/ruser.jsp";
	private static final String USER_PAGE = "jsp/user.jsp";
	private static final String LOGIN_PAGE = "Login.jsp";
	
	private boolean isValidLogon = false;
	private static DataBaseConnection dbConnection;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			dbConnection = new DataBaseConnection();
			req.setAttribute("connection", dbConnection);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		String userName = req.getParameter("uname");
		String password = req.getParameter("pass");
		HttpSession session = req.getSession();
		RequestDispatcher rd = null;
		String strErrMsg = null;
		try {
			HashMap<String, String> data = new HashMap<String, String>();
			data  = authenticateLogin(userName, password, data);
			if (isValidLogon) {			
				session.setAttribute("uname", userName);
				req.setAttribute("userName",data.get("firstName"));
				session.setMaxInactiveInterval(30*60);
				
	
				
				if(data.get("role").equals("admin")){
					rd = req.getRequestDispatcher(ADMIN_PAGE);
					session.setAttribute("authenticated", ADMIN_PAGE);
				}else if(data.get("role").equals("suser")){
					rd = req.getRequestDispatcher(SUSER_PAGE);
				}else if(data.get("role").equals("ruser")){
					rd = req.getRequestDispatcher(RUSER_PAGE);
				}else if(data.get("role").equals("user")){
					rd = req.getRequestDispatcher(USER_PAGE);
				}
				
				rd.forward(req,resp);
			} else {
				strErrMsg = "User name or Password is invalid. Please try again.";
				req.setAttribute("errorMsg", strErrMsg);
				rd = req.getRequestDispatcher(LOGIN_PAGE);
				rd.forward(req, resp);
			}
		} catch (Exception e) {
			strErrMsg = "Unable to validate user / password in database";
			session.setAttribute("errorMsg", strErrMsg);
			
		}

	}

	private HashMap<String, String> authenticateLogin(String userName, String password, HashMap<String, String> inpuData) {
		
		Connection conn = null;
		try {
			conn = dbConnection.getCon();
			PreparedStatement prepStmt = conn.prepareStatement(LOGIN_QUERY);
			prepStmt.setString(1, userName);
			prepStmt.setString(2, password);
			ResultSet rs = prepStmt.executeQuery();
			if (rs.next()) {
				System.out.println("User login is valid in DB" );
				inpuData.put("id", String.valueOf(rs.getInt(1)));
				inpuData.put("firstName", String.valueOf(rs.getString(2)));
				inpuData.put("lastName", String.valueOf(rs.getString(3)));
				inpuData.put("email", String.valueOf(rs.getString(4)));
				inpuData.put("role", String.valueOf(rs.getString(7)));
				isValidLogon = true;
			}
			
			

		} catch (Exception e) {
			System.out.println("validateLogon: Error while validating password: " + e.getMessage());
			e.printStackTrace();
		} 

		return inpuData;
	}

}
