package com.dervan.module.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dervan.module.dao.DataBaseConnection;

/**
 * Servlet implementation class RegistrationIndividual
 */
public class RegistrationIndividual extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static DataBaseConnection dbConnection;
	private static final String QUERY = "select * from game where type='IND' and CAST(REPLACE(AGE_GRP, 'U', '') AS UNSIGNED) < ? AND CATEGORY = ?";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationIndividual() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			dbConnection = new DataBaseConnection();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		HashMap<String, String> requestMap = new HashMap<>();
		
		requestMap.put("fname","'"+request.getParameter("fname")+"'");
		requestMap.put("fathername","'"+request.getParameter("fathername")+"'");
		requestMap.put("lname","'"+request.getParameter("lname")+"'");
		requestMap.put("address","'"+request.getParameter("address")+"'");
		requestMap.put("city","'"+request.getParameter("city")+"'");
		requestMap.put("pincode",request.getParameter("pincode"));
		requestMap.put("state","'"+request.getParameter("state")+"'");
		requestMap.put("school","'"+request.getParameter("clubname")+"'");
		requestMap.put("schaddress","'"+request.getParameter("clubaddress")+"'");
		requestMap.put("schcity","'"+request.getParameter("clubcity")+"'");
		requestMap.put("schpincode","'"+request.getParameter("clubpincode")+"'");
		requestMap.put("schstate","'"+request.getParameter("clubstate")+"'");
		requestMap.put("gender","'"+request.getParameter("gender")+"'");
		requestMap.put("dob",request.getParameter("dob"));
		requestMap.put("idtype","'"+request.getParameter("identitytype")+"'");
		requestMap.put("cidnumber","'"+request.getParameter("identitynumber")+"'");
		requestMap.put("bloodgroup","'"+request.getParameter("bloodgroup")+"'");
		requestMap.put("mobile",request.getParameter("mobile"));
		requestMap.put("emergency",request.getParameter("emergency"));
		requestMap.put("email","'"+request.getParameter("email")+"'");


		Connection conn = dbConnection.getCon();
		try {
			PreparedStatement stmt = conn.prepareStatement(QUERY);
			stmt.setInt(1, 15);
			if("MALE".equalsIgnoreCase(request.getParameter("gender"))){
				stmt.setString(2, "B");
			}else{
				stmt.setString(2, "G");
			}
			ResultSet rs = stmt.executeQuery();
			Map<String, List<String>> dataMap = new HashMap<>();
			ArrayList<String> archery = new ArrayList<>();
			ArrayList<String> athletics = new ArrayList<>();
			ArrayList<String> badminton = new ArrayList<>();
			ArrayList<String> carrom = new ArrayList<>();
			ArrayList<String> chess = new ArrayList<>();
			ArrayList<String> gymnastics = new ArrayList<>();
			ArrayList<String> shooting = new ArrayList<>();
			ArrayList<String> tt = new ArrayList<>();
			ArrayList<String> wallclimb = new ArrayList<>();
			ArrayList<String> yoga = new ArrayList<>();
			ArrayList<String> swimming = new ArrayList<>();
			
			
			while(rs.next()){
				System.out.println(rs.getString(1));
				if(rs.getString(2).equalsIgnoreCase("ARCHERY")){
					archery.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("ATHLETICS")){
					athletics.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("BADMINTON")){
					badminton.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("CARROM")){
					carrom.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("CHESS")){
					chess.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("GYMNASTICS")){
					gymnastics.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("SHOOTING")){
					shooting.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("SWIMMING")){
					swimming.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("TT")){
					tt.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("WALL CLIMBING")){
					wallclimb.add(rs.getString(5));
				}else if(rs.getString(2).equalsIgnoreCase("YOGA")){
					yoga.add(rs.getString(5));
				}
			}
			
			if(archery != null && !archery.isEmpty()){
				dataMap.put("ARCHERY", archery);
			}
			
			if(athletics != null && !athletics.isEmpty()){
				dataMap.put("ATHLETICS", athletics);
			}
			
			if(badminton != null && !badminton.isEmpty()){
				dataMap.put("BADMINTON", badminton);
			}
			
			if(carrom != null && !carrom.isEmpty()){
				dataMap.put("CARROM", carrom);
			}
			
			if(chess != null && !chess.isEmpty()){
				dataMap.put("CHESS", chess);
			}
			
			if(gymnastics != null && !gymnastics.isEmpty()){
				dataMap.put("GYMNASTICS", gymnastics);
			}
			
			if(shooting != null && !shooting.isEmpty()){
				dataMap.put("SHOOTING", shooting);
			}
			
			if(swimming != null && !swimming.isEmpty()){
				dataMap.put("SWIMMING", swimming);
			}
			
			if(tt != null && !tt.isEmpty()){
				dataMap.put("TT", tt);
			}
			
			if(wallclimb != null && !wallclimb.isEmpty()){
				dataMap.put("WALL CLIMBING", wallclimb);
			}
			
			if(yoga != null && !yoga.isEmpty()){
				dataMap.put("YOGA", yoga);
			}
			
			
			
			request.setAttribute("dataMap", dataMap);
			request.getRequestDispatcher("jsp/indigames.jsp").forward(request, response);
			
			
			HttpSession session = request.getSession();
			session.setAttribute("requestMap", requestMap);
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}

}
