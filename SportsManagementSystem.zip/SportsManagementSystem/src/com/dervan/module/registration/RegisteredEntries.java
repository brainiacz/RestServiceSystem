package com.dervan.module.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dervan.module.dao.DataBaseConnection;


public class RegisteredEntries extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisteredEntries() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		HashMap<String, String> participantData = (HashMap<String, String>) session.getAttribute("requestMap");
		String[] games = request.getParameterValues("checkedRows");
		
		ArrayList<String> discipline = new ArrayList<>();
		ArrayList<String> event = new ArrayList<>();
		
		for(String data : games){
			
			String[] str = data.split("\\|");
			discipline.add(str[0]);
			event.add(str[1]);
			
		}
		
		DataBaseConnection dbConnObj = null;
		Connection  connection = null;
		java.sql.Statement stmt = null;
		java.sql.Statement stmt1 = null;
		String partID = null;
		
		ArrayList<String> gameidList = new ArrayList<>();
		
		try {
			dbConnObj = new DataBaseConnection();
			connection = dbConnObj.getCon();
			stmt = connection.createStatement();
			stmt1 = connection.createStatement();
			discipline.removeAll(Arrays.asList("",null));
			event.removeAll(Arrays.asList("",null));

			String array1 = discipline.toString().replaceAll("[\\[\\]]","").replaceAll(", ", "','");
			String array2 = event.toString().replaceAll("[\\[\\]]","").replaceAll(", ", "','");
			
			String QUERY = "select game_id from game where discipline in ('"+array1+"') and event in ('"+array2+"')";
			
			String partQuery = "INSERT INTO PARTICIPANT (FNAME,MNAME,LNAME,DOB,AGE,SCHOOL,ADDRESS_LINE1,ADDRESS_LINE2,STATE,CITY,PINCODE,SCHOOL_ADDRESS_LINE1,SCHOOL_ADDRESS_LINE2,SCHOOL_STATE,SCHOOL_CITY,SCHOOL_PINCODE,GENDER,PHONE,EMER_PHONE,EMAIL_ID,BLOOD_GRP,ID_TYPE,ID_INT) VALUES ("
					+ participantData.get("fname") + ", '' , " + participantData.get("lname") + ",'2005-01-01',16, '', "
					+ participantData.get("address") + ", '', " + participantData.get("state") + ", "
					+ participantData.get("city") + ", " + participantData.get("pincode") + ", '', '', '', '', 461111, "
					+ participantData.get("gender") + "," + participantData.get("mobile") + ",'', "
					+ participantData.get("email") + ", '', " + participantData.get("idtype") + ", "
					+ participantData.get("idnumber") + ")";
			
			stmt1.executeUpdate(partQuery, Statement.RETURN_GENERATED_KEYS);
			ResultSet rs1 = stmt1.getGeneratedKeys();
			
			if(rs1.next()){
				partID = String.valueOf(rs1.getInt(1));
			}
			
			
			ResultSet rs = stmt.executeQuery(QUERY);
			while(rs.next()){
				gameidList.add(String.valueOf(rs.getInt(1)));
			}
			String part_game_query= null;
			
			for(String data : gameidList){
				part_game_query = "INSERT INTO PARTI_GAME (PART_ID, GAME_ID) VALUES ("+partID+", "+data+")";
				stmt1.execute(part_game_query);
			}
			
			request.setAttribute("partID", partID);
			request.getRequestDispatcher("jsp/message.jsp").forward(request, response);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
