package com.dervan.module.payments;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.dervan.module.dao.DataBaseConnection;
import com.dervan.module.model.Games;
import com.dervan.module.model.Participant;
import com.dervan.module.model.ParticipantGames;

public class IndividualPayments {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		DataBaseConnection connection = new DataBaseConnection();
		Connection con = connection.getCon();
		
		// get Participant Data
		Participant p = getParticipantDataPartID(con, "50000");
		
		List<ParticipantGames> list = getPartAndGameID(con, "50000");
		
		for(ParticipantGames p1 : list){
			System.out.println(p1.getGame_id());
		}
		System.out.println(p.getPart_id());
		
	}
	
	public static Participant getParticipantDataPartID(Connection con, String partID){
		
		PreparedStatement ps = null;
		Participant participant = null;
		try{
			participant = new Participant();
			String partQuery = "SELECT * FROM PARTICIPANT WHERE PART_ID = ?";
			ps = con.prepareStatement(partQuery);
			ps.setInt(1, Integer.valueOf(partID));
			ResultSet rs  = ps.executeQuery();
			
			while(rs.next()){
				participant.setPart_id(rs.getInt(1));
				participant.setFname(rs.getString(2));
				participant.setMname(rs.getString(3));
				participant.setLname(rs.getString(4));
				participant.setDob(rs.getDate(5));
				participant.setAge(rs.getInt(6));
				participant.setSchool(rs.getString(7));
				participant.setAddress(rs.getString(8));
				participant.setState(rs.getString(10));
				participant.setCity(rs.getString(11));	
				participant.setPincode(rs.getInt(12));
				participant.setSchAddress(rs.getString(13));
				participant.setSchState(rs.getString(15));
				participant.setSchity(rs.getString(16));
				participant.setSchPincode(rs.getInt(17));
				participant.setGender(rs.getString(18));
				participant.setPhone(rs.getString(19));
				participant.setEmPhone(rs.getString(20));
				participant.setEmail(rs.getString(21));
				participant.setBloodGrp(rs.getString(22));
				participant.setIdType(rs.getString(23));
				participant.setIdNumber(rs.getString(24));
				
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return participant;
	}
	
	public static List<ParticipantGames> getPartAndGameID(Connection con, String partID){
		PreparedStatement ps = null;
		ParticipantGames participantGames = null;
		ArrayList<ParticipantGames> gamesIDList = new ArrayList<ParticipantGames>();
		try{
			
			String partQuery = "SELECT * FROM PARTI_GAME WHERE PART_ID = ?";
			ps = con.prepareStatement(partQuery);
			ps.setInt(1, Integer.valueOf(partID));
			ResultSet rs  = ps.executeQuery();
			
			while(rs.next()){
				participantGames = new ParticipantGames();
				participantGames.setPart_id(rs.getInt(2));
				participantGames.setGame_id(rs.getInt(3));
				
				gamesIDList.add(participantGames);
				participantGames = null;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return gamesIDList;
	
	}
	
	
	public static List<Games> getGamesData(Connection con, List<ParticipantGames> gamesID){
		
		Statement stmt = null;
		Games games = null;
		ArrayList<Games> listOfGames = null;
		ArrayList<Integer> gameIDs = null;
		
		try {
			
			stmt = con.createStatement();
			gameIDs = new ArrayList<>();
			for(ParticipantGames partGames : gamesID){
				gameIDs.add(partGames.getGame_id());
			}
			
			gameIDs.removeAll(Arrays.asList("",null));

			String array1 = gameIDs.toString().replaceAll("[\\[\\]]","").replaceAll(", ", ",");
			
			String partQuery = "SELECT * FROM GAMES WHERE GAME_ID IN ("+array1+")";
			
			ResultSet rs = stmt.executeQuery(partQuery);
			
			while(rs.next()){
				games = new Games();
				games.setGame_id(rs.getInt(1));
				games.setDiscipline(rs.getString(2));
				games.setAge_grp(rs.getString(3));
				games.setCategory(rs.getString(4));
				games.setEvent(rs.getString(5));
				
				listOfGames.add(games);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return listOfGames;
	}
}
