package com.dervan.module.payments;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dervan.module.dao.DataBaseConnection;
import com.dervan.module.model.Participant;

/**
 * Servlet implementation class PaymentServlet
 */
public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static DataBaseConnection dbConnection;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try{
			dbConnection = new DataBaseConnection();
			Connection con = dbConnection.getCon();
			HttpSession session = request.getSession();
			
			String Id = request.getParameter("ID");
			String idValue = request.getParameter("options");
			
			
			Participant participantData = null;
			if(idValue.equalsIgnoreCase("PartID")){
				participantData = IndividualPayments.getParticipantDataPartID(con, Id);
			}
			
			session.setAttribute("Participant", participantData);
			request.setAttribute("Participant", participantData);
			request.getRequestDispatcher("jsp/payments_form.jsp").forward(request, response);
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
