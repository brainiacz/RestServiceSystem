package com.dervan.module.model;

public class ParticipantGames {
	
	private int parti_game_id;
	private int part_id;
	private int game_id;
	
	/**
	 * @return the parti_game_id
	 */
	public int getParti_game_id() {
		return parti_game_id;
	}
	/**
	 * @param parti_game_id the parti_game_id to set
	 */
	public void setParti_game_id(int parti_game_id) {
		this.parti_game_id = parti_game_id;
	}
	/**
	 * @return the part_id
	 */
	public int getPart_id() {
		return part_id;
	}
	/**
	 * @param part_id the part_id to set
	 */
	public void setPart_id(int part_id) {
		this.part_id = part_id;
	}
	/**
	 * @return the game_id
	 */
	public int getGame_id() {
		return game_id;
	}
	/**
	 * @param game_id the game_id to set
	 */
	public void setGame_id(int game_id) {
		this.game_id = game_id;
	}
}
