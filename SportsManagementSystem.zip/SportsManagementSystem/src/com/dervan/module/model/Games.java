package com.dervan.module.model;

public class Games {
	
	private int game_id;
	private String discipline;
	private String age_grp;
	private String category;
	private String event;
	
	/**
	 * @return the game_id
	 */
	public int getGame_id() {
		return game_id;
	}
	/**
	 * @param game_id the game_id to set
	 */
	public void setGame_id(int game_id) {
		this.game_id = game_id;
	}
	/**
	 * @return the discipline
	 */
	public String getDiscipline() {
		return discipline;
	}
	/**
	 * @param discipline the discipline to set
	 */
	public void setDiscipline(String discipline) {
		this.discipline = discipline;
	}
	/**
	 * @return the age_grp
	 */
	public String getAge_grp() {
		return age_grp;
	}
	/**
	 * @param age_grp the age_grp to set
	 */
	public void setAge_grp(String age_grp) {
		this.age_grp = age_grp;
	}
	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	/**
	 * @return the event
	 */
	public String getEvent() {
		return event;
	}
	/**
	 * @param event the event to set
	 */
	public void setEvent(String event) {
		this.event = event;
	}
	
	
}
