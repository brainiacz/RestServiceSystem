package com.dervan.module.model;

import java.util.Date;

public class Participant {
	private int part_id;
	private String fname;
	private String mname;
	private String lname;
	private Date dob;
	private int age;
	private String school;
	private String address;
	private String state;
	private String city;
	private int pincode;
	private String schAddress;
	private String schState;
	private String schity;
	private int schPincode;
	private String gender;
	private String phone;
	private String emPhone;
	private String email;
	private String bloodGrp;
	private String idType;
	private String idNumber;
	
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the part_id
	 */
	public int getPart_id() {
		return part_id;
	}
	/**
	 * @param part_id the part_id to set
	 */
	public void setPart_id(int part_id) {
		this.part_id = part_id;
	}
	/**
	 * @return the fname
	 */
	public String getFname() {
		return fname;
	}
	/**
	 * @param fname the fname to set
	 */
	public void setFname(String fname) {
		this.fname = fname;
	}
	/**
	 * @return the mname
	 */
	public String getMname() {
		return mname;
	}
	/**
	 * @param mname the mname to set
	 */
	public void setMname(String mname) {
		this.mname = mname;
	}
	/**
	 * @return the lname
	 */
	public String getLname() {
		return lname;
	}
	/**
	 * @param lname the lname to set
	 */
	public void setLname(String lname) {
		this.lname = lname;
	}
	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}
	/**
	 * @param dob the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @return the school
	 */
	public String getSchool() {
		return school;
	}
	/**
	 * @param school the school to set
	 */
	public void setSchool(String school) {
		this.school = school;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the pincode
	 */
	public int getPincode() {
		return pincode;
	}
	/**
	 * @param pincode the pincode to set
	 */
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	/**
	 * @return the schAddress
	 */
	public String getSchAddress() {
		return schAddress;
	}
	/**
	 * @param schAddress the schAddress to set
	 */
	public void setSchAddress(String schAddress) {
		this.schAddress = schAddress;
	}
	/**
	 * @return the schState
	 */
	public String getSchState() {
		return schState;
	}
	/**
	 * @param schState the schState to set
	 */
	public void setSchState(String schState) {
		this.schState = schState;
	}
	/**
	 * @return the schity
	 */
	public String getSchity() {
		return schity;
	}
	/**
	 * @param schity the schity to set
	 */
	public void setSchity(String schity) {
		this.schity = schity;
	}
	/**
	 * @return the schPincode
	 */
	public int getSchPincode() {
		return schPincode;
	}
	/**
	 * @param schPincode the schPincode to set
	 */
	public void setSchPincode(int schPincode) {
		this.schPincode = schPincode;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * @return the emPhone
	 */
	public String getEmPhone() {
		return emPhone;
	}
	/**
	 * @param emPhone the emPhone to set
	 */
	public void setEmPhone(String emPhone) {
		this.emPhone = emPhone;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the bloodGrp
	 */
	public String getBloodGrp() {
		return bloodGrp;
	}
	/**
	 * @param bloodGrp the bloodGrp to set
	 */
	public void setBloodGrp(String bloodGrp) {
		this.bloodGrp = bloodGrp;
	}
	/**
	 * @return the idType
	 */
	public String getIdType() {
		return idType;
	}
	/**
	 * @param idType the idType to set
	 */
	public void setIdType(String idType) {
		this.idType = idType;
	}
	/**
	 * @return the idNumber
	 */
	public String getIdNumber() {
		return idNumber;
	}
	/**
	 * @param idNumber the idNumber to set
	 */
	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}
	
	
	
	
}
